package step3;

import java.util.Scanner;

public class ManuViewr {
	static Scanner sc = new Scanner(System.in);
	public static void showMenu() {
		System.out.println("선택하세요???");
		 System.out.println("1. 데이터 입력.");
		 
		 System.out.println("5. 전체 출력");
		 
		 System.out.println("6. 프로그램 종료.");
		 System.out.print("메뉴선택====>");
		 
	}
}

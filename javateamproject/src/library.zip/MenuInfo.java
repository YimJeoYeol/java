package library;

public class MenuInfo {
    public static void showMenuInfo() {
        System.out.println("분류를 선택하세요");
        System.out.println("1. 도서");
        System.out.println("2. 회원");
        System.out.println("3. 종료");
    }
}
